# VisitorPing WordPress Plugin

Official WordPress plugin for **VisitorPing** — Real-time website visitor notifications & radar intelligence.

---

## 🎯 Purpose
Eliminates all technical code-editing requirements for non-technical small business owners using WordPress. Once installed, users simply paste their `Site Key` in WP Admin, and `vp.js` is automatically injected into `<head>` across their entire site.

---

## 📁 Plugin Structure

```text
plugins/wordpress/
├── visitorping.php                    # Main plugin initialization & hooks
├── uninstall.php                      # DB cleanup on plugin deletion
├── readme.txt                         # WordPress.org standard metadata & docs
├── README.md                          # Developer & deployment guide
├── includes/
│   ├── class-visitorping-tracker.php  # Front-end script injection & role exclusion
│   ├── class-visitorping-admin.php    # Admin settings, publishing secret & dashboard widget
│   └── class-visitorping-publisher.php # Signed publishing REST endpoints
└── assets/
    ├── css/
    │   └── admin.css                  # Polished WP Admin UI styling
    └── js/
        └── admin.js                   # Interactive connection verification handler
```

---

## 🛠 Features

1. **Zero-Code Onboarding**: Simple settings page in `WP Admin` $\rightarrow$ `Settings` $\rightarrow$ `VisitorPing`.
2. **Auto-Injection**: Injects the subscription-aware `https://cdn.visitorping.com/site/{SITE_KEY}.js` script on all public front-end pages.
3. **Role Exclusion**: Automatically suppresses tracking for logged-in Administrators and Editors so site owners never trigger alerts on their own browsing.
4. **Script Verification**: Built-in AJAX verification button in WP Admin to confirm that the tracking script is reachable.
5. **Dashboard Widget**: Adds a quick status widget in the WordPress Dashboard.
6. **Content Delivery**: Creates reviewed posts through timestamped HMAC-signed requests. Delivery is idempotent, and posts are created as drafts unless you separately enable scheduled publishing. The endpoints can never update or delete an existing post.

## Draft publishing setup

1. In WordPress, open **Settings → VisitorPing**.
2. Enable **Allow VisitorPing to create WordPress drafts** and save. Leave **Also allow VisitorPing to publish scheduled daily articles** off unless you want one scheduled article per day to go live without review.
3. Copy the generated publishing secret.
4. In VisitorPing, open **SEO → Content Growth**, select the same website, and paste the WordPress URL and secret.
5. Write and save an article, type `SEND AS DRAFT`, and approve delivery.
6. Review and publish the result from WordPress when ready.

Rotating the secret in WordPress immediately invalidates the saved VisitorPing connection. The secret is stored encrypted by VisitorPing and is never displayed there after pairing.

---

## 📦 Packaging for Distribution (.zip)

To build a `.zip` file for manual upload or distribution:

```bash
node scripts/build-wordpress-plugin.mjs
```

Run `pnpm test:platforms` from the repository root before distributing the ZIP.

The builder creates `visitorping-wordpress.zip` at the repository root and updates the public download at `apps/web/public/downloads/visitorping-wordpress.zip`. Both contain the `visitorping/` plugin directory and removal instructions. Rebuild the ZIP whenever plugin sources change. WordPress.org listing approval is separate; do not promise directory search availability until verified.
